let myLeads = [];

const inputEl = document.getElementById("input-el");
const inputBtn = document.getElementById("input-btn");
const ulEl = document.getElementById("ul-el");

inputBtn.addEventListener("click", function () {
  console.log("button clicked from event listener");

  myLeads.push(inputEl.value);
  console.log(myLeads);
  //ulEl.innerHTML += "<li>" + inputEl.value + "</li>";
  inputEl.value = "";
  renderLeads();
});

function renderLeads() {
  let listItems = "";
  for (let i = 0; i < myLeads.length; i++) {
    console.log(myLeads[i]);
    listItems += `<li>
        <a target = '_blank' href= '${myLeads[i]}'> ${myLeads[i]}</a>
      </li>`;
  }
  ulEl.innerHTML = listItems;
}
